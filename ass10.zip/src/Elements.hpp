#pragma once

struct Element8Bytes
{
	char data[8];
};

struct Element512Bytes
{
	char data[512];
};

struct Element8MB 
{
	char data[8 * 1024 * 1024];
};
